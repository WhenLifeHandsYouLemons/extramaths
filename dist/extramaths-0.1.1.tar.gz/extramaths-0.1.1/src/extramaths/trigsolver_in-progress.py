# Imports
import math

# Trigonometry solver
def right_angle_trig(hypotenuse, opposite, adjacent, angle):
    if hypotenuse == None:
        print(hypotenuse)
    if opposite == None:
        print(opposite)
    if adjacent == None:
        print(adjacent)
    if angle == None:
        print(angle)

right_angle_trig(43, 23, 45, 4)
